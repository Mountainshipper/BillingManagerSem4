package applicationMain.ui.addBill

data class Bill(val title: String? = null, val price: String?= null, val date: String?= null, val steuer: String?= null )
